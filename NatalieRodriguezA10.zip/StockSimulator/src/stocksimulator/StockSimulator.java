/**
 * Title: Stock Simulator Assignment 10
 * Semester: COP3337 – Spring 2018
 *
 * @author Natalie Rodriguez
 *
 * I affirm that this program is entirely my own work and none of it is the work
 * of any other person.
 *
 * This program is supposed to use collections to simulate a stock buy/selling
 * system and utilize a map queue to add stocks to on top of each other and
 * sells the stocks by removing them in FIFO manner. Unfortunately, I did not
 * understand how to implement these concepts well despite my efforts and the
 * given resources. My project is incomplete.
 */
package stocksimulator;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * Class for simulating trading a single stock at varying prices.
 */
public class StockSimulator {

    private Map<String, Queue<Block>> blocks;
    Queue<Block> portfolio;

    /**
     * Constructor.
     */
    public StockSimulator() {

    }

    /**
     * Handle a user buying a given quantity of stock at a given price.
     *
     * @param symbol
     * @param quantity how many to buy.
     * @param price the price to buy.
     */
    public void buy(String symbol, int quantity, int price) {
        portfolio = new LinkedList<>(); // will hold quantity and price
        blocks = new TreeMap(); //hold symbol and list  
        
        //Adds a portfolio to the block
        if (portfolio == null) {
            blocks.put(symbol, portfolio);
        }

        portfolio.add(new Block(quantity, price));

        blocks.put(symbol, portfolio); //Stores the stocks

        for (Map.Entry<String, Queue<Block>> entry : blocks.entrySet()) {
            String key = entry.getKey();
            Block value = (Block) entry.getValue();
            System.out.print(key + " : " + value.toString());

        }

    }

    /**
     * Handle a user selling a given quantity of stock at a given price.
     *
     * @param symbol the stock to sell
     * @param quantity how many to sell.
     * @param price the price to sell.
     */
    public void sell(String symbol, int quantity, int price) {

        Scanner scn = new Scanner(System.in);
        System.out.println("How many stocks would you like to sell?");
        int sell = scn.nextInt();

        for (Map.Entry<String, Queue<Block>> entry : blocks.entrySet()) {
            String key = entry.getKey();
            for (Block value : entry.getValue()) {
                System.out.print(key + " : " + value);
            }
        }

    }

}
