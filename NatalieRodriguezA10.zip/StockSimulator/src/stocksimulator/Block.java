package stocksimulator;

/**
 *
 * Class of setters and getters from user inputs.
 */
public class Block {

    private final int price;
    private int quantity;

    /**
     * Constructor.
     *
     * @param quantity the quantity of this block.
     * @param price the price of this block.
     */
    public Block(int quantity, int price) {
        this.price = price;
        this.quantity = quantity;
    }

    /**
     * Gets amount of stocks.
     *
     * @return stock amount
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Gets the price of the stock.
     *
     * @return price of stock
     */
    public int getPrice() {
        return price;
    }

    /**
     * Sells the stock and updates the quantity of stocks.
     *
     * @param shares number of total shares
     */
    public void sell(int shares) {
        quantity -= shares;
    }
}
